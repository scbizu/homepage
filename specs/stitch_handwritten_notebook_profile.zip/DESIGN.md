---
name: Analog Notebook
colors:
  surface: '#fbf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#fbf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ef'
  surface-container: '#efeeea'
  surface-container-high: '#eae8e4'
  surface-container-highest: '#e4e2de'
  on-surface: '#1b1c1a'
  on-surface-variant: '#45464f'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f0ed'
  outline: '#757680'
  outline-variant: '#c5c6d0'
  surface-tint: '#4e5d8c'
  primary: '#000e37'
  on-primary: '#ffffff'
  primary-container: '#142450'
  on-primary-container: '#7d8cbe'
  inverse-primary: '#b6c5fa'
  secondary: '#705d00'
  on-secondary: '#ffffff'
  secondary-container: '#ffda49'
  on-secondary-container: '#735f00'
  tertiary: '#2f0001'
  on-tertiary: '#ffffff'
  tertiary-container: '#560003'
  on-tertiary-container: '#fe4e43'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b6c5fa'
  on-primary-fixed: '#061844'
  on-primary-fixed-variant: '#364572'
  secondary-fixed: '#ffe174'
  secondary-fixed-dim: '#e7c433'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#554500'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4ab'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#930009'
  background: '#fbf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e4e2de'
  paper-bg: '#fbf9f5'
  ink-blue: '#142450'
  highlighter-yellow: '#ffda49'
  correction-red: '#ba1a1a'
  tape-blue: rgba(150, 165, 217, 0.4)
  rule-line: '#e5e7eb'
typography:
  display-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.1'
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
  annotation:
    fontFamily: Karla
    fontSize: 15px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  baseline: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  gutter: 32px
  rule-height: 24px
---

## Brand & Style

The brand identity is rooted in the concept of a "Digital Sandbox"—a space that celebrates the beauty of human imperfection, tactile creation, and the bridge between analog and digital workflows. It targets creatives, designers, and developers who value authenticity over clinical precision.

The design style is a sophisticated blend of **Tactile Brutalism** and **Scrapbook Aesthetic**. It utilizes high-contrast typography, hand-drawn physical metaphors (like "washi tape," "polaroid" frames, and "red ink" corrections), and a structural grid that mimics a physical notebook. The emotional response is intended to be warm, approachable, and intellectually stimulating, evoking the nostalgia of a personal journal combined with a modern web experience.

## Colors

The palette is centered on a "Paper and Ink" philosophy. The background uses a soft, off-white `paper-bg` to reduce eye strain and mimic recycled stock. `ink-blue` serves as the primary color for text and structural elements, providing deep contrast.

Accent colors are used as functional "tools":
- **Correction Red:** Used for hand-drawn annotations, arrows, and circles to draw attention to specific details.
- **Highlighter Yellow:** Used for background emphasis behind text, simulating a physical marker.
- **Tape Blue:** A semi-transparent shade used for decorative "washi tape" elements.
- **Rule Line Gray:** Used for the underlying horizontal grid lines that establish the vertical rhythm.

## Typography

The typographic system uses high-personality pairings to reinforce the notebook theme.
- **Headlines:** Use *Bricolage Grotesque* for a quirky, bold, and modern feel. It should be used for site titles and section headers.
- **Body:** Use *Work Sans* for maximum readability. It provides a clean, neutral balance to the more expressive headers.
- **Labels:** *Be Vietnam Pro* in all-caps provides a structured, technical feel for metadata and categorization.
- **Annotations:** *Karla* (often italicized) is used for "marginalia"—handwritten notes, dates, and photo captions—simulating the author's own handwriting or a secondary pen.

## Layout & Spacing

The layout is governed by a **Vertical Rhythm Grid**. A 24px horizontal rule-line pattern is applied to the background, and all text elements, margins, and section spacing should align to this 24px baseline (or multiples thereof).

- **Structure:** A fixed-width central container (max-6xl) is used for desktop. 
- **Margins:** Generous outer margins (64px desktop) create "white space" that feels like a physical page border. 
- **Red Margin Line:** A vertical red line (2px, 20% opacity) is fixed at the left margin, mimicking the margin line of a standard composition notebook.
- **Breakpoints:** On mobile, margins reduce to 20px and the red line shifts accordingly.

## Elevation & Depth

This system avoids traditional shadows in favor of **Structural Stacking** and **Tactile Overlays**:
- **Tonal Stacking:** Depth is achieved by placing white cards (`#ffffff`) over the off-white paper background (`#fbf9f5`).
- **Physical Metaphors:** Elements like "Polaroid" photos use a subtle `2px 2px` solid offset shadow (10% black) rather than a blur, creating a flat, printed-paper depth.
- **Washi Tape:** Decorative semi-transparent overlays are used to "anchor" elements to the page, appearing to sit on a higher Z-index.
- **Organic Borders:** The `sketch-border` uses a custom CSS `border-radius` (irregular percentages) to simulate a hand-drawn rectangle.

## Shapes

The shape language is defined by "Deliberate Imperfection." While standard buttons and cards use a base `rounded-sm` (0.125rem) or `rounded-lg` (0.25rem), the primary container style is the **Sketch Border**.

The Sketch Border uses irregular border-radii (e.g., `255px 15px 225px 15px / 15px 225px 15px 255px`) to create an organic, hand-drawn look. This should be applied to primary buttons and featured content cards. High-impact elements may also include a subtle `rotate` (1 to 2 degrees) to mimic items scattered on a desk.

## Components

### Buttons
- **Primary:** Uses the `sketch-border`, thick `ink-blue` text, and no background color. On hover, it fills with `highlighter-yellow` and triggers a "wiggle" animation.
- **Ghost:** Simple text with a wavy underline for navigation items.

### Cards
- **Sketch Cards:** Enclosed in a sketch-border with 24px padding. Hovering triggers a subtle perspective tilt.
- **Polaroid:** A white card with a larger bottom margin for annotation text, containing a grayscale image that transitions to color on hover.

### Inputs & UI Elements
- **Red Circle:** Used to highlight specific words within a paragraph.
- **Highlighter:** A background gradient applied to text spans to mimic marker strokes.
- **Hand Arrow:** Use the `Material Symbols Outlined` "trending_flat" icon in `correction-red` to act as a hand-drawn bullet point.

### Lists
- Lists are unstyled by default but should use the "Hand Arrow" for item indicators in featured sections.